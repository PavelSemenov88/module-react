import './button-end.scss';

function ButtonEnd({text}) {
  return (
    <div className='button-end'>{text}</div>
  )
}

export default ButtonEnd;