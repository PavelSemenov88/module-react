import './Notfound.scss';


function Notfound() {
  return (
    <main className="notfound">
      <div className="container">
        <header className="header__notfound">Такой страницы не существует</header>
      </div>
    </main>
  );
}

export default Notfound;